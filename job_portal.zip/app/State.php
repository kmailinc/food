<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class State extends Model
{
    public $timestamps = false;
    use SoftDeletes; 

    public function districts()
    {
        return $this->hasMany('App\District','state_id');
    }

}
