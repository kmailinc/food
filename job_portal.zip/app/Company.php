<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Company extends Model
{
    use SoftDeletes;
    public function users()
    {
        return $this->hasMany('App\User','company_id');
    }
    public function jobs()
    {
        return $this->hasMany('App\Job','company_id');
    }
    
}
