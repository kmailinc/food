<?php

namespace App\Http\Middleware;

use Closure;
use App\User;
use Illuminate\Http\Request;

class ApiAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */

     

    public function handle($request, Closure $next)
    {
        
        $api_token = $request->api_token; 
         
        if(empty($api_token)){
            return response()->json(['error' => 'api_token not set'], 401);
        }    

        $user = User::where('api_token', $api_token)->first();
        if(!$user){
            return response()->json(['error' => 'Api token not valie'], 401);
        }

        $request->user = $user;
        

        return $next($request);
    }
}
