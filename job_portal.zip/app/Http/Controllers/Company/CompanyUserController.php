<?php

namespace App\Http\Controllers\Company;

use App\Company;
use App\Industry;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use DB;
use App\Config; 
use View;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Auth;



class CompanyUserController extends Controller
{
    var $config_arr = array();
    var $company;
    public function __construct()
    {
        $this->middleware('auth');

        $arr = array();
        $arr['view_folder'] = "company.users";
        $arr['singular_name'] = "Company User";
        $arr['plural_name'] = "Company Users";
        $arr['table_name'] = "users";
        $arr['update_route_name'] = 'company.user_update';
        $arr['edit_route_name'] = 'company.user_edit';
        $arr['delete_route_name'] = 'company.user_delete';
        $arr['listing_url'] = ajaxUrl(route('company.users'));
        $arr['create_url'] = ajaxUrl(route("company.user_create"));
        
        
         
        $this->config_arr =   $arr;

    }
    public function index(Request $request)
    {
        
       $company = Auth::user()->company; 

       if(!$company){
        echo "Company Not available";
        die();
       }

       $users = $company->users;

       $carr = $this->config_arr; 


       

       $view_path = getAdminViewFolderPath($carr,"_list");
       return view($view_path,compact('carr','users','company'));      

    }
    
    public function create(Request $request)
    {
       $company = Auth::user()->company; 

       if(!$company){
        echo "Company Not available";
        die();
       }
        
        $obj = $this->getEmptyObject();
        $obj->id            = 0;
       
       

        $carr               = $this->config_arr; 
         
        

        $view_path = getAdminViewFolderPath($carr,"_form");
        return view($view_path,compact('obj','carr','company'));
    }
     
    
    public function edit(Request $request, $id = 0)
    {
       $company = Auth::user()->company; 

       if(!$company){
        echo "Company Not available";
        die();
       }

        $obj = $this->findById($id);
        if(!$obj){
            return view('error.record_not_found');
        }

        $carr               = $this->config_arr; 
        
        

        $view_path = getAdminViewFolderPath($carr,"_form"); 
          
        return view($view_path,compact('obj','carr','company'));
    }

    public function update(Request $request, $id = 0)
    {   
       $company = Auth::user()->company; 

       if(!$company){
            $result_array = array( 'result' => "error",'message' => "Company Not available",'error_list' => "");
            return response()->json($result_array);
            exit;
       }

        $carr = $this->config_arr; 
        

        $url = "";

        $v_arr =  array();
    
        $v_arr['email']  = "required|unique:users,email,".$id;
        $v_arr['first_name']  = "required";
        $v_arr['last_name']  = "required";

        if($request->change_password or $id == 0){
            $v_arr['password']  = "required|string|min:8";    
        }

        
        
          
        $v = Validator::make($request->all(), $v_arr );
        if ($v->fails())
        {   
            return response()->json(getValidationErrorJson($v));
            exit;
        }

        // Check unique email id
        if($id){
            $obj = $this->findById($id);
            if(!$obj){
                $result_array = array( 'result' => "error",'message' => $carr['singular_name']." Not found",'error_list' => "");
                return response()->json($result_array);
                exit;
            }
            $success_message = $carr['singular_name']. " Upated";
            

        }else{
            $obj = $this->getEmptyObject();
            $obj->company_id         = $company->id;
            $obj->api_token         = Str::random(60);
             
            $url = $carr['listing_url'];
            $success_message = $carr['singular_name'] ." Created";
      
        } 
        $obj->email         = $request->email;
        $obj->first_name    = $request->first_name;
        $obj->last_name     = $request->last_name;
        if($request->change_password or $id == 0){
           $obj->password      = Hash::make($request->password);
           if($id >= 0){
                createEvent(Auth::user()->id , "Company user password changed","");
           }
        }
       
        $obj->save();
        
        
        $changes = $obj->getChanges();
        if($id == 0){
            createEvent(Auth::user()->id , "Company user created","","User",$obj->id);
        }else{
            if(sizeof($changes)){
                unset($changes['updated_at']);
                if(isset($changes['password'])){
                    unset($changes['password']);    
                }
                

                $desc = serialize($changes);
                createEvent(Auth::user()->id , "Company user updated",$desc,"User",$obj->id);
            }
        }


        
    
           
        $result_array = array( 'result' => "success",'message' => $success_message , 'url' => $url);
        return response()->json($result_array);
        exit;

    }
     

     
    public function delete(Request $request, $company_id = 0 , $id = 0)
    {   
        $carr = $this->config_arr;

        $obj = User::where("id",$id)->where('company_id',$company_id)->first();
        if(!$obj){
            $result_array = array( 'result' => "error",'message' => $carr['singular_name']." not found",'error_list' => "");
            return response()->json($result_array);
            exit;
        }
        $obj->delete();
        $success_message = $carr['singular_name']." Deleted";

        $result_array = array( 'result' => "success",'message' => $success_message);
        $result_array['data_callback'] = 'hide_rable_row';
        return response()->json($result_array);
        exit;
    }

    public function getEmptyObject(){
         return new User();
    }
    public function findById($id){
        $company = Auth::user()->company; 

        return User::where("id",$id)->where('company_id',$company->id)->first();
    }
}
