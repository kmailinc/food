<?php

namespace App\Http\Controllers\Company;
 
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;

class DashboardController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
        
    }

    public function index(Request $request)
    {
        	
       $company = Auth::user()->company; 

       if(!$company){
        echo "Company Not available";
        die();
       }

       $user_count = $company->users->count();
       $total_jobs = $company->jobs->count();

        return view('company.dashboard',compact('user_count','total_jobs'));



    }
      
}
