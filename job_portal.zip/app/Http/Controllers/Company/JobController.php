<?php

namespace App\Http\Controllers\Company;

use App\Job;
use App\JobCategory;
use App\User;
use App\Company;
use App\JobSkill;
use App\Skill;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use DB;
use App\Config; 
use View;
use Auth;

class JobController extends Controller
{
    var $config_arr = array();
    var $company;
    public function __construct()
    {
        $this->middleware('auth');

        $arr = array();
        $arr['view_folder'] = "company.jobs";
        $arr['singular_name'] = "Job";
        $arr['plural_name'] = "Jobs";
        $arr['table_name'] = "jobs";
        $arr['update_route_name'] = 'company.job_update';
        $arr['edit_route_name'] = 'company.job_edit';
        $arr['delete_route_name'] = 'company.job_delete';
        $arr['listing_url'] = ajaxUrl(route('company.jobs'));
        $arr['create_url'] = ajaxUrl(route("company.job_create"));
        
        
         
        $this->config_arr =   $arr;

    }

     public function index(Request $request)
    {

       $company = Auth::user()->company; 

       if(!$company){
        echo "Company Not available";
        die();
       }
 	   $carr = $this->config_arr; 
 	   $view_path = getAdminViewFolderPath($carr,"_list");
       return view($view_path,compact('carr','company'));      

    }
    public function processing(Request $request){
       
        $company = Auth::user()->company; 

        $carr = $this->config_arr;     

        $visible_header = array("id","title","role","experience","salary" ,"end_date", "option");
        $db_header = array("title","role");
        $start = $request->start;
        $length = $request->length;

        $LIMIT_STR = "limit  $start, $length";

        $draw = $request->draw;
        $search_req = $request->search;
        $search = $search_req['value'];        

         
        
        /* global search */

        $LIKE_STR = '';
        if($search != ''){
          $LIKE_STR = " AND ";
          foreach($db_header as $key=>$header){         
            $_field =  $header ;
            $LIKE_STR .= '`companies`.`'.$_field."` LIKE '%".$search."%' OR ";    
            
               
          } 
          $LIKE_STR = trim(trim($LIKE_STR," "),"OR");
        }



        $join = "   jobs LEFT JOIN job_categories ON jobs.category_id = job_categories.id ";
        
        
        $select = " `jobs`.*,`job_categories`.`category_name` ";
        

        $WHERE = " WHERE `jobs`.`company_id` = {$company->id} ";

 
        $SQL_ALL = "SELECT  $select FROM $join $WHERE $LIKE_STR $LIMIT_STR";

        
        
        //dd($SQL_ALL);
        $data_obj = DB::select($SQL_ALL);        

        $COUNT_ALL = "SELECT count(*) as total_records FROM  $join $WHERE $LIKE_STR";
        $total_obj = DB::select($COUNT_ALL);
        $SELECT_SQL = "";

        $table = array();
        $table['draw'] = $draw;
        $table['recordsTotal'] = $total_obj[0]->total_records;
        $table['recordsFiltered'] = $total_obj[0]->total_records;
        $table_data = array();

         
        foreach ($data_obj as $key => $data_row){

            $data_raw_obj = Job::where("id",$data_row->id)->first(); 
            $_data = array();
            $element_id = $data_row->id; 
            foreach($visible_header as $key=>$header){
                $_header = "";
                if ($header == "option") {
                    $obj = $data_raw_obj;
                    $view_path = getAdminViewFolderPath($carr,"_options");
                    $_header.= (string)View::make(  $view_path ,compact('obj','element_id','carr'));
                    
                }
                elseif($header == "salary"){
                     $_header = $data_raw_obj->salary_text();
                }
                elseif($header == "experience"){
                     $_header = $data_raw_obj->experience_text();
                }
                else{
                    $_header = $data_row->$header;
                }
              
              $_data[] = $_header;
            }
            $table_data[] = $_data;
        }

        $table['data'] = $table_data;

        return $table;

 

    }
    public function create(Request $request)
    {
       $company = Auth::user()->company; 

       if(!$company){
        echo "Company Not available";
        die();
       }
        
        $obj = $this->getEmptyObject();
        $obj->id            = 0;
       	$obj->work_experience_from = 0;
       	$obj->work_experience_to = 1;
       	$obj->salary_offer_from = 0;
       	$obj->salary_offer_to = 0;
       

        $carr               = $this->config_arr; 
        $job_ategories		= JobCategory::all();
        $skills             = Skill::all();
        $job_skils          = array();

        

        $view_path = getAdminViewFolderPath($carr,"_form");
        return view($view_path,compact('obj','carr','company','job_ategories','skills','job_skils'));
    }
     
    
    public function edit(Request $request, $id = 0)
    {
       $company = Auth::user()->company; 

       if(!$company){
        echo "Company Not available";
        die();
       }

        $obj = $this->findById($id);
        if(!$obj){
            return view('error.record_not_found');
        }

        $carr               = $this->config_arr; 
        $job_ategories		= JobCategory::all();
        $skills             = Skill::all();

        $job_skils          = $obj->skills->pluck('skill_id')->toArray();
        
        
        

        $view_path = getAdminViewFolderPath($carr,"_form"); 
          
        return view($view_path,compact('obj','carr','company','job_ategories','skills','job_skils'));
    }

    public function update(Request $request, $id = 0)
    {   
       $company = Auth::user()->company; 

       if(!$company){
            $result_array = array( 'result' => "error",'message' => "Company Not available",'error_list' => "");
            return response()->json($result_array);
            exit;
       }

        $carr = $this->config_arr; 
        

        $url = "";

        $v_arr =  array();
    
        $v_arr['title']  = "required|max:190";
        $v_arr['role']  = "required|max:190";
        $v_arr['category_id'] = "required";
        $v_arr['description']  = "required";
        $v_arr['work_experience_from']  = "required";
        $v_arr['work_experience_to']  = "required|integer|min:1";
        $v_arr['salary_offer_from']  = "required";
        $v_arr['salary_offer_to']  = "required";
         

        
        
          
        $v = Validator::make($request->all(), $v_arr );
        if ($v->fails())
        {   
            return response()->json(getValidationErrorJson($v));
            exit;
        }

        // Check unique email id
        if($id){
            $obj = $this->findById($id);
            if(!$obj){
                $result_array = array( 'result' => "error",'message' => $carr['singular_name']." Not found",'error_list' => "");
                return response()->json($result_array);
                exit;
            }
            $success_message = $carr['singular_name']. " Upated";
            

        }else{
            $obj = $this->getEmptyObject();
            $obj->company_id         = $company->id;
             
            $url = $carr['listing_url'];
            $success_message = $carr['singular_name'] ." Created";
      
        }
        $obj->title                 = $request->title;
        $obj->role                  = $request->role;
        $obj->category_id           = $request->category_id;
        $obj->description           = $request->description;
        $obj->work_experience_to    = $request->work_experience_to;
        $obj->salary_offer_from     = $request->salary_offer_from;
        $obj->salary_offer_to       = $request->salary_offer_to;

        if($request->end_date and strtotime($request->end_date)){
            $obj->end_date =   date("Y-m-d",strtotime($request->end_date));
        }
         
         
        $obj->save();


        $changes = $obj->getChanges();
        if($id == 0){
            createEvent(Auth::user()->id , "Job created","","Job",$obj->id);
        }else{
            if(sizeof($changes)){
                unset($changes['updated_at']);
                if(isset($changes['password'])){
                    unset($changes['password']);    
                }
                

                $desc = serialize($changes);
                createEvent(Auth::user()->id , "Job updated",$desc,"Job",$obj->id);
            }
        }

        // Save Skills
        if($request->skills and is_array($request->skills)){
            $skils_ids = $request->skills;

            foreach($skils_ids as $skill){
                if (!JobSkill::where('job_id', $obj->id)->where("skill_id",$skill)->exists()){
                    $job_skill = new JobSkill();
                    $job_skill->job_id = $obj->id;
                    $job_skill->skill_id = $skill;
                    $job_skill->save();
                }
            }

            // delete rest of jobs
            $delete_obj = JobSkill::where("job_id",$obj->id);
            $delete_obj->whereNotIn('skill_id',$skils_ids);
            $delete_obj->delete();
        }
        
    
           
        $result_array = array( 'result' => "success",'message' => $success_message , 'url' => $url);
        return response()->json($result_array);
        exit;

    }
     

     
    public function delete(Request $request, $company_id = 0 , $id = 0)
    {   
        $carr = $this->config_arr;

        $obj = User::where("id",$id)->where('company_id',$company_id)->first();
        if(!$obj){
            $result_array = array( 'result' => "error",'message' => $carr['singular_name']." not found",'error_list' => "");
            return response()->json($result_array);
            exit;
        }
        $obj->delete();
        $success_message = $carr['singular_name']." Deleted";

        $result_array = array( 'result' => "success",'message' => $success_message);
        $result_array['data_callback'] = 'hide_rable_row';
        return response()->json($result_array);
        exit;
    }

    public function getEmptyObject(){
         return new Job();
    }
    public function findById($id){
        $company = Auth::user()->company; 

        return Job::where("id",$id)->where('company_id',$company->id)->first();
    }
}
