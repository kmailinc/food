<?php

namespace App\Http\Controllers\Company;

use App\UserAddress;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Company;
use App\Industry;
use App\User;
use Auth;
use App\State;
use App\District;
 

class RegisterController extends Controller
{
    var $config_arr = array();
    var $company;
    public function __construct()
    {
        $this->middleware('auth');

        $arr = array();
        $arr['view_folder'] = "company.company";
        $arr['singular_name'] = "Company";
        $arr['table_name'] = "company";
        $arr['update_route_name'] = 'company.register_post';
        $arr['create_url'] = ajaxUrl(route("company.user_create"));
        
        
         
        $this->config_arr =   $arr;

    }

    public function index(Request $request)
    {
       $company = Auth::user()->company; 
        
       if($company and  $company->status == 1){
            return redirect()->route('company.company');
        }

       $carr = $this->config_arr; 
       $view_path = getAdminViewFolderPath($carr,"_registration");
       return view($view_path,compact('carr'));  
    }
    public function register_form(Request $request)
    {
        $carr = $this->config_arr;  
       
       $obj = Auth::user()->company_with_trashed; 
       if(!$obj){
        $obj = new Company(); 
       }
       if($obj->deleted_at != null){
        $view_path = getAdminViewFolderPath($carr,"_deleted");
        return view($view_path,compact('carr','obj'));  
       }
        
       
       
       $states             = State::all();
       $districts          = District::where('state_id',$obj->state_id)->get(); 
       $industries         = Industry::all();

       $view_path = getAdminViewFolderPath($carr,"_register_form");
       return view($view_path,compact('carr','obj','industries','states','districts'));  
    }
    public function register_post(Request $request)
    {   

        $id = $request->id;
        $user =  Auth::user();

        $carr = $this->config_arr; 
        $url = "";

        $v_arr =  array();
    
        $v_arr['company_name']  = "required|unique:companies,company_name,".$id;
        $v_arr['industry_id']  = "required";
        $v_arr['district_id']  = "required";
        $v_arr['state_id']  = "required";
        $v_arr['nagar_palika']  = "required";
        $v_arr['polic_station'] = "required";
        $v_arr['pin_code'] = "required|digits:6"; 
        
        
          
        $v = Validator::make($request->all(), $v_arr );
        if ($v->fails())
        {   
            return response()->json(getValidationErrorJson($v));
            exit;
        }

        // Check unique email id
       $obj = $user->company; 

       $new_company = 0;

       $success_message = $carr['singular_name'] ." Updated";
       if(!$obj){
            $obj = new Company();
            $obj->status = 0;  
            $url = "#register/success";
            $success_message = $carr['singular_name'] ." Created"; 
            $new_company = 1;
       }
        

       $allow_params = array();
       $allow_params[]  = "company_name";
       $allow_params[]  = "industry_id";
       $allow_params[]  = "district_id";
       $allow_params[]  = "state_id";
       $allow_params[]  = "url";
       $allow_params[]  = "description";
       $allow_params[]  = "is_consultant";
       $allow_params[] = "nagar_palika";
       $allow_params[] = "block";
       $allow_params[] = "village";
       $allow_params[]  = "house_number";
       $allow_params[]  = "polic_station";
       $allow_params[]  = "pin_code";
       

       foreach ($allow_params as $params){
        if($request->$params){
            $obj->$params = $request->$params;
        }
       }
       $obj->save();
       $user->company_id = $obj->id;
       $user->save(['timestamps' => false]);
       


       if($new_company){
          createEvent(Auth::user()->id , "Company created","","Company",$obj->id); 
       }else{
          $changes = $obj->getChanges();
          if(sizeof($changes)){
                unset($changes['updated_at']);
                if(isset($changes['password'])){
                    unset($changes['password']);    
                }
                

                $desc = serialize($changes);
                createEvent(Auth::user()->id , "Company updated",$desc,"Company",$obj->id);
            }
       }
       
        
           
        $result_array = array( 'result' => "success",'message' => $success_message , 'url' => $url);
        return response()->json($result_array);
        exit;
    }

    

    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function success()
    {
        $carr = $this->config_arr; 
        $view_path = getAdminViewFolderPath($carr,"_success");
        return view($view_path,compact('carr'));  
    }

    
}
