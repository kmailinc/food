<?php

namespace App\Http\Controllers;

use App\JobEducation;
use Illuminate\Http\Request;

class JobEducationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\JobEducation  $jobEducation
     * @return \Illuminate\Http\Response
     */
    public function show(JobEducation $jobEducation)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\JobEducation  $jobEducation
     * @return \Illuminate\Http\Response
     */
    public function edit(JobEducation $jobEducation)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\JobEducation  $jobEducation
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, JobEducation $jobEducation)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\JobEducation  $jobEducation
     * @return \Illuminate\Http\Response
     */
    public function destroy(JobEducation $jobEducation)
    {
        //
    }
}
