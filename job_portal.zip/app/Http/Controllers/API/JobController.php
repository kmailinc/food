<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Job;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use App\UserJob;
use Illuminate\Support\Str;

class JobController extends Controller
{
     
  public function index(Request $request)
    {
        $user       = $request->user;
        $company    = $user->company;
        
        // $jobs       = $company->jobs->simplePaginate(15);
        $jobs       = Job::where('company_id',$company->id)->Paginate(10);
        foreach($jobs as $job){
            $job->salary_text = $job->salary_text();
            $job->experience_text = $job->experience_text();
              $job->skills_array();

        }
       return response()->json(['success' =>1, 'data'=> $jobs ]);
    }
    public function apply(Request $request){

        $v_arr =  array();
        $v_arr['job_id']  = "required";
        $v_arr['resume']  =  "required|mimetypes:application/pdf,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/msword|max:10000";
        $customMessages = [
          'mimetypes' => 'Resume file type must be pdf or valid word document file'
        ];
        $v = Validator::make($request->all(), $v_arr ,$customMessages);
        if ($v->fails())
        {   
            return response()->json(getValidationErrorJson($v));
            exit;
        }


        $job_id = $request->job_id;
        $job    = Job::where('id',$job_id)->where('status',1)->where('end_date' , '>=' , Carbon::now()->toDateTimeString())->first();
        if(!$job){
          return response()->json(['success' => 0, 'message'=> "Job not available" ]);   
        }
        if(strtotime($job->end_date) < time()) {
          return response()->json(['success' => 0, 'message'=> "Job requirement close" ]);
        }

        $user       = $request->user;

        $userjob = UserJob::where('job_id',$job->id)->where('user_id',$user->id)->first();
        if($userjob){
          return response()->json(['success' => 0, 'message'=> "Already applied job" ]);
        }

        $userjob = new UserJob();
        $userjob->job_id = $job->id;
        $userjob->user_id = $user->id;
        $userjob->status = 1;
        $userjob->shortlist = 0;
        $userjob->save();

        $changes = $address->getChanges();
        
        createEvent($user->id , "User Applied on Job","","UserJob",$userjob->id);
         



        $this->uploadResume($request , $userjob);

        $userjob->resume_url = $userjob->resume_url();

        return response()->json(['success' =>1, 'data'=> $userjob ]);

        
        // UserJob

        
    }
    public function uploadResume(Request $request , $userjob)
    {   
        $destinationPath = public_path($userjob->resume_public_path());
        
        if ($request->hasFile('resume')) {

            $image = $request->file('resume');
            
            // // delete Old image
            //  $full_path = $destinationPath."/".$media->media_path;
            //  if(!empty($media->media_path) and is_file($full_path)  and file_exists($full_path)){
            //     unlink($full_path);
            //  }
 
            $rand_name = time()."_".Str::random(7)."_".Str::random(7);
            $name = $rand_name .'.'.$image->getClientOriginalExtension();
           
            $image->move($destinationPath, $name);
            $userjob->resume = $name;
            $userjob->save();
        }
       
    }
    public function job_search(Request $request){



        
    }

    
}
