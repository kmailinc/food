<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Skill;
class SkillController extends Controller
{
     
    public function index()
    {
         return response()->json(['success' =>1, 'data'=> Skill::all() ]);
    }

     
}
