<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use App\User;
use App\Mail\WelcomeMail;
use Illuminate\Support\Facades\Mail;

class LoginController extends Controller
{
     
    public function index(Request $request)
    {    
        $username = $request->username;   
        $password = $request->password; 
        if (Auth::attempt(['email' => $username, 'password' => $password])) {
             return response()->json(['success' =>1, 'data'=> Auth::user() ]);
        }
        return response()->json(['error' =>'not authorized']);
    }

    public function register(Request $request)
    {   

    	$v_arr =  array();
    	$id = 0;
        $v_arr['email']  = "required|unique:users,email,".$id;
        $v_arr['first_name']  = "required";
        $v_arr['last_name']  = "required";
        $v_arr['password']  = "required|string|min:8";    
        

        $v = Validator::make($request->all(), $v_arr );
        if ($v->fails())
        {   
            return response()->json(getValidationErrorJson($v));
            exit;
        }
        
        $user = new User();
        $user->api_token     = Str::random(60);
        $user->email         = $request->email;
        $user->first_name    = $request->first_name;
        $user->last_name     = $request->last_name;
        $user->password      = Hash::make($request->password);
        $user->save();

        createEvent($user->id , "User Registered","","User",$user->id);

        // Mail::to($user->email)->send(new WelcomeMail($user));
        // Mail::to("dk.mca61@gmail.com")->send(new WelcomeMail($user));


        return response()->json(['success' =>1, 'data'=> $user ]);
    }

    
 
}
