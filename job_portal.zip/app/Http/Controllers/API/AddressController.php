<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\District;
use App\State;
use App\UserAddress;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
class AddressController extends Controller
{
    public function states(Request $request)
    {
        return response()->json(['success' =>1, 'data'=> State::select("id","name")->get() ]);
    }
    public function districts(Request $request)
    {   
        $v_arr =  array();
        $v_arr['state_id']  = "required|numeric";
        
        $v = Validator::make($request->all(), $v_arr );
        if ($v->fails())
        {   
            return response()->json(getValidationErrorJson($v));
            exit;
        }
        

        $state_id = $request->state_id;
        $districts = District::select("id","name")->where('state_id', $state_id)->get();

        
        return response()->json(['success' =>1, 'data'=> $districts ]);
    }
    
    public function address(Request $request)
    {       

        $user = $request->user;
        return response()->json(['success' =>1, 'data'=> $user->addresses ]);





    }    
    public function update_address(Request $request)
    {       

        $v_arr =  array();
        $v_arr['state_id']  = "required|numeric";
        $v_arr['district_id']  = "required|numeric";
        $v_arr['nagar_palika']  = "required";
        // $v_arr['block']  = "required";
        // $v_arr['village']  = "required";
        // $v_arr['house_number']  = "required";
        $v_arr['polic_station']  = "required";
        $v_arr['pin_code']  = "required|digits:6";
        $v_arr['type']  = "required|in:home,current,both";
        //'home', 'current','both'
        

        $v = Validator::make($request->all(), $v_arr );
        if ($v->fails())
        {   
            return response()->json(getValidationErrorJson($v));
            exit;
        }

        $user = $request->user;
        $type = $request->type;

        $address =  $user->addresses->where('type',$type)->first();

        $new_address = 0;

        if(!$address){
            $address = new UserAddress();
            $address->type = $type;
            $address->user_id = $user->id;
            $new_address = 1;
        }

        $address->state_id = $request->state_id;
        $address->district_id = $request->district_id;
        $address->nagar_palika = $request->nagar_palika;
        $address->polic_station = $request->polic_station;
        $address->pin_code  = $request->pin_code;
        $address->type = $type;
        if($request->block){
            $address->block = $request->block;
        }
        if($request->village){
            $address->village = $request->village;
        }
        if($request->house_number){
            $address->house_number = $request->house_number;
        }

        $address->save();

        $changes = $address->getChanges();
        if($new_address){
            createEvent($user->id , "User Address created","","UserAddress",$address->id);
        }else{
            if(sizeof($changes)){
                unset($changes['updated_at']);
                if(isset($changes['password'])){
                    unset($changes['password']);    
                }
                

                $desc = serialize($changes);
                createEvent($user->id , "User Address updated",$desc,"UserAddress",$address->id);
            }
        }


        return response()->json(['success' =>1, 'data'=> $address ]);





    }    
    
}
