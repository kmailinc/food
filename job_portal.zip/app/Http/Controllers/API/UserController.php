<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use App\User;


class UserController extends Controller
{
     
    
    public function my_info(Request $request)
    {   
    	$user = $request->user;
    	return response()->json(['success' =>1, 'data'=> $user ]);
    }
    public function update_user_info(Request $request)
    {   

    	$v_arr =  array();
    	$v_arr['first_name']  = "required|min:2";
        $v_arr['last_name']  = "required|min:2";
        $v_arr['gender']  = "required|in:male,female,other";
        $v_arr['marital_status']  = "required|in:married,unmarried,other";
        $v_arr['mother_name']  = "required|min:2";
        $v_arr['father_name']  = "required|min:2";
        $v_arr['adharnumber']  = "required|digits:12";
        $v_arr['birthdate']  = "required|date";
        
        if($request->hasFile('photo')){
            $v_arr['photo']  =  "required|mimes:jpeg,bmp,png|max:10000";    
        }
        
         
        $customMessages = [];
         

        $v = Validator::make($request->all(), $v_arr ,$customMessages);
        if ($v->fails())
        {   
            return response()->json(getValidationErrorJson($v));
            exit;
        }
        
        $user = $request->user;
        $user->first_name    = $request->first_name;
        $user->last_name    = $request->last_name;
        $user->gender    = $request->gender;
        $user->marital_status    = $request->marital_status;
        $user->mother_name    = $request->mother_name;
        $user->father_name    = $request->father_name;
        $user->adharnumber         = $request->adharnumber;
        $user->birthdate  = date("Y-m-d",strtotime($request->birthdate));
        if($request->husband_wife_name){
        	$user->husband_wife_name = $request->husband_wife_name;
		}         
        $user->save();


        $changes = $user->getChanges();
        
        if(sizeof($changes)){
            unset($changes['updated_at']);
            if(isset($changes['password'])){
                unset($changes['password']);    
            }
            $desc = serialize($changes);
            createEvent($user->id , "User updated",$desc,"User",$user->id);
        }
         



        $this->uploadPhoto($request , $user);
        $user->photo_url = $user->photo_url();

        $user->makeHidden(['api_token','email_verified_at']);

        return response()->json(['success' =>1, 'data'=> $user ]);
        
    }
    public function uploadPhoto(Request $request , $user)
    {   
        $destinationPath = public_path($user->photo_public_path());
        
        if ($request->hasFile('photo')) {

            $image = $request->file('photo');
            
            // // delete Old image
            //  $full_path = $destinationPath."/".$media->media_path;
            //  if(!empty($media->media_path) and is_file($full_path)  and file_exists($full_path)){
            //     unlink($full_path);
            //  }
 
            $rand_name = time()."_".Str::random(7)."_".Str::random(7);
            $name = $rand_name .'.'.$image->getClientOriginalExtension();
           
            $image->move($destinationPath, $name);
            $user->photo = $name;
            $user->save();
        }
       
    }

     
}
