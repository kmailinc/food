<?php

namespace App\Http\Controllers;

use App\UserJob;
use Illuminate\Http\Request;
use App\User;
use App\Mail\WelcomeMail;
use Illuminate\Support\Facades\Mail;


class TestController extends Controller
{   
     public function index()
    {
     $user = User::find(1);

     Mail::to("dk.mca61@gmail.com")->send(new WelcomeMail($user));
    }


}
