<?php

namespace App\Http\Controllers\Admin;;

use App\JobCategory;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use DB;
use App\Config; 
use View;
use Illuminate\Support\Str;

class JobCategoryController extends Controller
{
    var $config_arr = array();
    public function __construct()
    {
        $this->middleware('auth:admin');
        $arr = array();
        $arr['view_folder'] = "admin.job_categories";
        $arr['singular_name'] = "Job Category";
        $arr['plural_name'] = "Job Categories";
        $arr['table_name'] = "job_categories";
        $arr['update_route_name'] = 'admin.job_category_update';
        $arr['edit_route_name'] = 'admin.job_category_edit';
        $arr['delete_route_name'] = 'admin.job_category_delete';
        $arr['listing_url'] = ajaxUrl(route('admin.job_categories'));
        $arr['create_url'] = ajaxUrl(route('admin.job_category_create'));
        $this->config_arr = $arr;

    }
    public function index(Request $request)
    {
       $deleted = 0;
       if($request->deleted == 1){
         $deleted = 1;
         $categories = JobCategory::onlyTrashed()->get();
       }else{
          $categories = JobCategory::all(); 
       }

       $carr = $this->config_arr; 
       $view_path = getAdminViewFolderPath($carr,"_list");
       return view($view_path,compact('carr','categories','deleted'));      

    }

     public function create(Request $request)
    {
        
        
        $obj = $this->getEmptyObject();
        $obj->id            = 0;
       
       

        $carr               = $this->config_arr; 
        
        $view_path = getAdminViewFolderPath($carr,"_form");
        return view($view_path,compact('obj','carr'));
    }
     
    
    public function edit(Request $request, $id = 0)
    {
        $obj = $this->findById($id);
        if(!$obj){
            return view('error.record_not_found');
        }

        $carr = $this->config_arr; 
        $view_path = getAdminViewFolderPath($carr,"_form"); 
          
        return view($view_path,compact('obj','carr'));
    }

    public function update(Request $request, $id = 0)
    {   
        $carr = $this->config_arr; 
        $url = "";

        $v_arr =  array();
    
        $v_arr['category_name']  = "required|unique:job_categories,category_name,".$id;;
          
        $v = Validator::make($request->all(), $v_arr );
        if ($v->fails())
        {   
            return response()->json(getValidationErrorJson($v));
            exit;
        }

        // Check unique email id
        if($id){
            $obj = $this->findById($id);
            if(!$obj){
                $result_array = array( 'result' => "error",'message' => $carr['singular_name']." Not found",'error_list' => "");
                return response()->json($result_array);
                exit;
            }
            $success_message = $carr['singular_name']. " Upated";
            

        }else{
            $obj = $this->getEmptyObject();
             
            $url = $carr['listing_url'];
            $success_message = $carr['singular_name'] ." Created";
      
        }
        $obj->category_name = $request->category_name;
        $obj->save();


        $changes = $obj->getChanges();
       if($id == 0){
          createAdminEvent("Job Category Created","","JobCategory",$obj->id); 
       }else{
            if(sizeof($changes)){
                unset($changes['updated_at']);
                $desc = serialize($changes);
                createAdminEvent("Job Category Updated",$desc,"JobCategory",$obj->id);
            }
       }
        
    
           
        $result_array = array( 'result' => "success",'message' => $success_message , 'url' => $url);
        return response()->json($result_array);
        exit;

    }
     

     
    public function delete(Request $request, $id = 0)
    {   
        $carr = $this->config_arr;

        $obj = $this->findById($id);
        if(!$obj){
            $result_array = array( 'result' => "error",'message' => $carr['singular_name']." not found",'error_list' => "");
            return response()->json($result_array);
            exit;
        }

        if($request->restore == 1){
            $obj->restore();
             $success_message = $carr['singular_name']." Restored";
        }else{
            $obj->delete();
             $success_message = $carr['singular_name']." Deleted";    
        }

        
       

        $result_array = array( 'result' => "success",'message' => $success_message);
        $result_array['data_callback'] = 'hide_rable_row';
        return response()->json($result_array);
        exit;
    }

    public function getEmptyObject(){
         return new JobCategory();
    }
    public function findById($id){

        return JobCategory::withTrashed()->where("id",$id)->first();
    }
}
