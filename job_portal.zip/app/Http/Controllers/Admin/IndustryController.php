<?php

namespace App\Http\Controllers\Admin;

use App\Industry;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use DB;
use App\Config; 
use View;
use Illuminate\Support\Str;;

class IndustryController extends Controller
{
    var $config_arr = array();
    public function __construct()
    { 
        $this->middleware('auth:admin');
        $arr = array();
        $arr['view_folder'] = "admin.industries";
        $arr['singular_name'] = "Industry";
        $arr['plural_name'] = "Industries";
        $arr['table_name'] = "industries";
        $arr['update_route_name'] = 'admin.industry_update';
        $arr['edit_route_name'] = 'admin.industry_edit';
        $arr['delete_route_name'] = 'admin.industry_delete';
        $arr['listing_url'] = ajaxUrl(route('admin.industries'));
        $arr['create_url'] = ajaxUrl(route('admin.industry_create'));
        $this->config_arr = $arr;

    }
    public function index(Request $request)
    {  
       $deleted = 0;
       if($request->deleted == 1){
            $deleted = 1;
            $industries = Industry::onlyTrashed()->get();
        }else{
            $industries = Industry::all();     
       }  

        
       $carr = $this->config_arr; 
       $view_path = getAdminViewFolderPath($carr,"_list");
       return view($view_path,compact('carr','industries','deleted'));      

    }

     public function create(Request $request)
    {
        
        
        $obj = $this->getEmptyObject();
        $obj->id            = 0;
       
       

        $carr               = $this->config_arr; 
        
        $view_path = getAdminViewFolderPath($carr,"_form");
        return view($view_path,compact('obj','carr'));
    }
     
    
    public function edit(Request $request, $id = 0)
    {
        $obj = $this->findById($id);
        if(!$obj){
            return view('error.record_not_found');
        }

        $carr = $this->config_arr; 
        $view_path = getAdminViewFolderPath($carr,"_form"); 
          
        return view($view_path,compact('obj','carr'));
    }

    public function update(Request $request, $id = 0)
    {   
        $carr = $this->config_arr; 
        $url = "";

        $v_arr =  array();
    
        $v_arr['industry_name']  = "required|unique:industries,industry_name,".$id;
          
        $v = Validator::make($request->all(), $v_arr );
        if ($v->fails())
        {   
            return response()->json(getValidationErrorJson($v));
            exit;
        }

        // Check unique email id
        if($id){
            $obj = $this->findById($id);
            if(!$obj){
                $result_array = array( 'result' => "error",'message' => $carr['singular_name']." Not found",'error_list' => "");
                return response()->json($result_array);
                exit;
            }
            $success_message = $carr['singular_name']. " Upated";
            

        }else{
            $obj = $this->getEmptyObject();
             
            $url = $carr['listing_url'];
            $success_message = $carr['singular_name'] ." Created";
      
        }
        $obj->industry_name = $request->industry_name;
        $obj->save();

        $changes = $obj->getChanges();
       if($id == 0){
          createAdminEvent("Industry Created","","Industry",$obj->id); 
       }else{
            if(sizeof($changes)){
                unset($changes['updated_at']);
                $desc = serialize($changes);
                createAdminEvent("Industry Updated",$desc,"Industry",$obj->id);
            }
       }
        
    
           
        $result_array = array( 'result' => "success",'message' => $success_message , 'url' => $url);
        return response()->json($result_array);
        exit;

    }
     

     
    public function delete(Request $request, $id = 0)
    {   
        $carr = $this->config_arr;

        $obj = $this->findById($id);
        if(!$obj){
            $result_array = array( 'result' => "error",'message' => $carr['singular_name']." not found",'error_list' => "");
            return response()->json($result_array);
            exit;
        }
        if($request->restore == 1){
            $obj->restore();
             $success_message = $carr['singular_name']." Restored";
        }else{
            $obj->delete();
             $success_message = $carr['singular_name']." Deleted";    
        }
        $result_array = array( 'result' => "success",'message' => $success_message);
        $result_array['data_callback'] = 'hide_rable_row';
        return response()->json($result_array);
        exit;
    }

    public function getEmptyObject(){
         return new Industry();
    }
    public function findById($id){

        return Industry::withTrashed()->where("id",$id)->first();
    }
}
