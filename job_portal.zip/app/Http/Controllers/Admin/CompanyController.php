<?php

namespace App\Http\Controllers\Admin;

use App\Company;
use App\Industry;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use DB;
use App\Config; 
use View;
use Illuminate\Support\Str;
use App\State;
use App\District;
use Auth;


class CompanyController extends Controller
{
    var $config_arr = array();
    public function __construct()
    {
        $this->middleware('auth:admin');
        $arr = array();
        $arr['view_folder'] = "admin.companies";
        $arr['singular_name'] = "Company";
        $arr['plural_name'] = "Companies";
        $arr['table_name'] = "companies";
        $arr['update_route_name'] = 'admin.company_update';
        $arr['edit_route_name'] = 'admin.company_edit';
        $arr['delete_route_name'] = 'admin.company_delete';
        $arr['listing_url'] = ajaxUrl(route('admin.companies'));
        $arr['create_url'] = ajaxUrl(route('admin.company_create'));
        $this->config_arr =$arr;

    }
    public function index(Request $request)
    {
       

       $deleted = 0;
       if($request->deleted == 1){
            $deleted = 1;
            $companies = Company::onlyTrashed()->get();
        }else{
            $companies = Company::all();     
        }  
        
       $carr = $this->config_arr; 
       $view_path = getAdminViewFolderPath($carr,"_list");
       return view($view_path,compact('carr','companies','deleted'));      

    }
    public function processing(Request $request){
        
       $deleted = 0;
       if($request->deleted == 1){
            $deleted = 1;
       }

       $carr = $this->config_arr;     

        $visible_header = array("id","company_name","address" ,"url",'status', "option");
        $db_header = array("company_name","address");
        $start = $request->start;
        $length = $request->length;

        $LIMIT_STR = "limit  $start, $length";

        $draw = $request->draw;
        $search_req = $request->search;
        $search = $search_req['value'];        

         
        
        /* global search */

        $LIKE_STR = '';
        if($search != ''){
          $LIKE_STR = " AND ";
          foreach($db_header as $key=>$header){         
            $_field =  $header ;
            $LIKE_STR .= '`companies`.`'.$_field."` LIKE '%".$search."%' OR ";    
            
               
          } 
          $LIKE_STR = trim(trim($LIKE_STR," "),"OR");
        }



        $join = "   companies LEFT JOIN industries ON companies.industry_id = industries.id ";
        
        
        $select = " `companies`.*,`industries`.`industry_name` ";
        
        if($deleted == 0){
            $WHERE = " WHERE `companies`.`deleted_at` IS null ";
        }else{
            $WHERE = " WHERE `companies`.`deleted_at` IS NOT NULL ";
        }

        $ORDER_BY_STR = " ORDER BY `companies`.`id` DESC ";
        
        $SQL_ALL = "SELECT  $select FROM $join $WHERE $LIKE_STR $ORDER_BY_STR $LIMIT_STR";
        

        
        
        //dd($SQL_ALL);
        $data_obj = DB::select($SQL_ALL);        

        $COUNT_ALL = "SELECT count(*) as total_records FROM  $join $WHERE $LIKE_STR";
        $total_obj = DB::select($COUNT_ALL);
        $SELECT_SQL = "";

        $table = array();
        $table['draw'] = $draw;
        $table['recordsTotal'] = $total_obj[0]->total_records;
        $table['recordsFiltered'] = $total_obj[0]->total_records;
        $table_data = array();

         
        foreach ($data_obj as $key => $data_row){

            $data_raw_obj = Company::withTrashed()->where("id",$data_row->id)->first(); 
            $_data = array();
            $element_id = $data_row->id; 
            foreach($visible_header as $key=>$header){
                $_header = "";
                if ($header == "option") {
                    $obj = $data_raw_obj;
                    $view_path = getAdminViewFolderPath($carr,"_options");
                    $_header.= (string)View::make(  $view_path ,compact('obj','element_id','carr','deleted'));
                    
                }
                else if($header == "status"){
                    if($data_row->$header == 1){
                        $_header = '<span class="label label-green">Active</span>';    
                    }else{
                        $_header = '<span class="label label-danger">De-Active</span>';
                    }
                    
                }
                else{
                    $_header = $data_row->$header;
                }
              
              $_data[] = $_header;
            }
            $table_data[] = $_data;
        }

        $table['data'] = $table_data;

        return $table;

 

    }

    public function create(Request $request)
    {
        
        
        $obj = $this->getEmptyObject();
        $obj->id            = 0;
       
       

        $carr               = $this->config_arr; 
        $states             = State::all();
        $districts          = District::where('state_id',$obj->state_id)->get(); 
        
        $industries         = Industry::all();
        
        $view_path = getAdminViewFolderPath($carr,"_form");
        return view($view_path,compact('obj','carr','industries','states','districts'));
    }
     
    
    public function edit(Request $request, $id = 0)
    {
        $obj = $this->findById($id);
        if(!$obj){
            return view('error.record_not_found');
        }

        $carr               = $this->config_arr; 
        $states             = State::all();
        $districts          = District::where('state_id',$obj->state_id)->get(); 
        
        $industries         = Industry::all();
        $view_path = getAdminViewFolderPath($carr,"_form"); 
          
        return view($view_path,compact('obj','carr','industries','states','districts'));
    }

    public function update(Request $request, $id = 0)
    {   
        $carr = $this->config_arr; 
        $url = "";

        $v_arr =  array();
    
        
        $v_arr['company_name']  = "required|unique:companies,company_name,".$id;
        $v_arr['industry_id']  = "required";
        $v_arr['district_id']  = "required";
        $v_arr['state_id']  = "required";
        $v_arr['nagar_palika']  = "required";
        $v_arr['polic_station'] = "required";
        $v_arr['pin_code'] = "required|digits:6"; 
        
          
        $v = Validator::make($request->all(), $v_arr );
        if ($v->fails())
        {   
            return response()->json(getValidationErrorJson($v));
            exit;
        }

        // Check unique email id
        if($id){
            $obj = $this->findById($id);
            if(!$obj){
                $result_array = array( 'result' => "error",'message' => $carr['singular_name']." Not found",'error_list' => "");
                return response()->json($result_array);
                exit;
            }
            $success_message = $carr['singular_name']. " Upated";
            

        }else{
            $obj = $this->getEmptyObject();
             
            $url = $carr['listing_url'];
            $success_message = $carr['singular_name'] ." Created";
      
        }
       $allow_params = array();
       $allow_params[]  = "company_name";
       $allow_params[]  = "industry_id";
       $allow_params[]  = "district_id";
       $allow_params[]  = "state_id";
       $allow_params[]  = "url";
       $allow_params[]  = "description";
       $allow_params[]  = "is_consultant";
       $allow_params[] = "nagar_palika";
       $allow_params[] = "block";
       $allow_params[] = "village";
       $allow_params[]  = "house_number";
       $allow_params[]  = "polic_station";
       $allow_params[]  = "pin_code";


       foreach ($allow_params as $params){
        if($request->$params){
            $obj->$params = $request->$params;
        }
       }
       $obj->status = $request->status;
       $obj->save();

      $changes = $obj->getChanges();
       

      if($id == 0){
          createAdminEvent("Company created","","Company",$obj->id); 
       }else{
            if(sizeof($changes)){
                

                
                unset($changes['updated_at']);
                $desc = serialize($changes);
                createAdminEvent("Company updated",$desc,"Company",$obj->id);
            }
       }
        

       
        
    
           
        $result_array = array( 'result' => "success",'message' => $success_message , 'url' => $url);
        return response()->json($result_array);
        exit;

    }
     

     
    public function delete(Request $request, $id = 0)
    {   
        $carr = $this->config_arr;

        $obj = $this->findById($id);
        if(!$obj){
            $result_array = array( 'result' => "error",'message' => $carr['singular_name']." not found",'error_list' => "");
            return response()->json($result_array);
            exit;
        }
        if($request->restore == 1){
            $obj->restore();
            $success_message = $carr['singular_name']." Restored";
            createAdminEvent($success_message,"","Company",$obj->id); 
        }else{
            $obj->status = 0;
            $obj->save();
            $obj->delete();
            $success_message = $carr['singular_name']." Deleted";  
            createAdminEvent($success_message,"","Company",$obj->id);   
        }

        $result_array = array( 'result' => "success",'message' => $success_message);
        // $result_array['data_callback'] = 'hide_rable_row';
        return response()->json($result_array);
        exit;
    }

    public function getEmptyObject(){
         return new Company();
    }
    public function findById($id){

        return Company::withTrashed()->where("id",$id)->first();
    }
}
