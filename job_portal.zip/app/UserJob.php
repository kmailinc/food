<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserJob extends Model
{
    public function resume_public_path(){
        return "/jobs/resume/".$this->job_id;
    }
    public function resume_url(){

    	if(!empty($this->resume)){

            return asset("public".$this->resume_public_path()."/".$this->resume);
        }
        return "";
    }
}
