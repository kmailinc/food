<?php 
use App\Event;

  
function ajaxUrl($url){
	$base_url = URL::to('/');
	$tmp = str_replace($base_url,"",$url);
	$tmp = trim($tmp,"/");
    return "#".$tmp;  
}
 function getAdminViewFolderPath($carr , $string){

    return  $carr['view_folder'].".".$carr['table_name']. $string;
}
function getValidationErrorJson($v){
    $html = '';
    $error = array();
    $e = $v->messages();
    foreach ($v->messages()->getMessages() as $key => $errors){
        foreach($errors as $error){
            $html .= $error."<br>";
        }
    }
    $error_message = $html;
    $result_array = array('success'=>0 ,'result' => "error",'message' => $error_message,'error_list' => $e);

    return $result_array;
} 

function statusHtml($status){
	$html  = "<span class='label label-danger'>InActive</span>";
    if($status){
        $html = "<span class='label label-success'>Active</span>";
    }
    return $html;
}
function visibleDateFormat($date){

	if(strtotime($date) > 10000){
		return date("d-m-Y",strtotime($date));
	}
	return "";


}
function createAdminEvent($name , $desc , $model_name = "", $model_id = 0){
    $user_id =  Auth::guard('admin')->user()->id;
    createEvent(0 , $name , $desc , $model_name, $model_id ,$user_id);
    
}
function createEvent($user_id , $name , $desc , $model_name = "", $model_id = 0,$admin_id = 0){

    if(!empty($name)){
        $event = new Event();
        $event->name = $name;
        if($user_id){
            $event->user_id = $user_id;
        }
        $event->description = $desc;
        if(!empty($model_name)){
            $event->model_name = $model_name;
        }
        if($model_id){
            $event->model_id = $model_id;
        }
        if($admin_id){
            $event->admin_id = $admin_id;
        }
        $event->model_name = $model_name;
        $event->save();
    }
    


}

 


 
