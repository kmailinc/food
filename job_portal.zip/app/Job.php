<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Job extends Model
{
    
    public function experience_text(){
    	return $this->work_experience_from."-". $this->work_experience_to ." Yrs";
    }
    public function salary_text(){
    	if($this->salary_offer_from == 0){
    		return "Not Disclosed";
    	}
    	return $this->salary_offer_from." - ". $this->salary_offer_to ." P.A";
    }

    public function skills()
    {
        return $this->hasMany('App\JobSkill','job_id');
    }
    public function skills_array(){
        $arr = array();
        foreach($this->skills as $skill){
            $arr[] = array("id" => $skill->skill_id, "skill_name"=> $skill->skill_name());


        }
        return $arr;
    }
}
