<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JobSkill extends Model
{
  	public function job()
    {
        return $this->belongsTo('App\Job','job_id');
    }  
    public function skill()
    {
        return $this->belongsTo('App\Skill','skill_id');
    }
    public function skill_name()
    {
        $skill = $this->skill;
        if($skill){
        	return $skill->skill_name;
        }
        return "";
    }   
}
