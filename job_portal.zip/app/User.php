<?php

namespace App;

use Illuminate\Notifications\Notifiable;
// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'first_name','last_name' ,'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function photo_public_path(){
        return "/user/photo/".date("m-Y",strtotime($this->created_at));
    }
    public function photo_url(){

        if(!empty($this->photo)){

            return asset("public".$this->photo_public_path()."/".$this->photo);
        }
        return "";
    }



    public function full_name()
    {
        return trim($this->first_name ." ". $this->last_name);
    }


    public function company()
    {
        return $this->belongsTo('App\Company','company_id');
    } 
    public function company_with_trashed()
    {
        return $this->belongsTo('App\Company','company_id')->withTrashed();
    } 

    public function company_name(){
        $company = $this->company;
        if($company){
            return $company->company_name;
        }
        return "";


    }
    public function addresses()
    {
        return $this->hasMany('App\UserAddress','user_id');
    }

}
