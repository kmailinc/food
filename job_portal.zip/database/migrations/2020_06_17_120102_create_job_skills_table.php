<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateJobSkillsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('job_skills', function (Blueprint $table) {
            $table->bigIncrements('id');
            
            $table->unsignedBigInteger('job_id')->nullable();;
            $table->foreign('job_id')->references('id')->on('jobs')->onDelete('set null');

            $table->unsignedSmallInteger('skill_id')->nullable();;
            $table->foreign('skill_id')->references('id')->on('skills')->onDelete('set null');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('job_skills');
    }
}
