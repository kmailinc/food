<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUserAddressesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_addresses', function (Blueprint $table) {
            $table->bigIncrements('id');
            
            $table->unsignedBigInteger('user_id')->nullable();;
            $table->foreign('user_id')->references('id')->on('users')->onDelete('set null');

            $table->unsignedBigInteger('state_id')->nullable();;
            $table->foreign('state_id')->references('id')->on('states')->onDelete('set null');

            $table->unsignedBigInteger('district_id')->nullable();;
            $table->foreign('district_id')->references('id')->on('districts')->onDelete('set null');

            $table->string('nagar_palika',50)->default('');
            $table->string('block',50)->default('');
            $table->string('village',50)->default('');
            $table->string('house_number',20)->default('');
            $table->string('polic_station',50)->default('');
            $table->string('pin_code',10)->default('');
            $table->enum('type', ['home', 'current','both'])->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_addresses');
    }
}
