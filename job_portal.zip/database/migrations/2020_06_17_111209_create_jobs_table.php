<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateJobsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('jobs', function (Blueprint $table) {
            $table->bigIncrements('id');

            $table->unsignedSmallInteger('company_id')->nullable();;
            $table->foreign('company_id')->references('id')->on('companies')->onDelete('set null');

            $table->unsignedSmallInteger('category_id')->nullable();;
            $table->foreign('category_id')->references('id')->on('job_categories')->onDelete('set null');

            $table->unsignedSmallInteger('sub_category_id')->nullable();;
            $table->foreign('sub_category_id')->references('id')->on('job_subcategories')->onDelete('set null');
 

            $table->string('title')->default('');
            $table->text('description')->nullable();
            $table->string('role')->default('');
            $table->smallInteger('work_experience_from')->default(0);
            $table->smallInteger('work_experience_to')->default(0);
            $table->integer('salary_offer_from')->default(0);
            $table->integer('salary_offer_to')->default(0);
            $table->date("end_date")->nullable();
            $table->boolean('status')->default(1);
            $table->boolean('featured')->default(0);


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('jobs');
    }
}
