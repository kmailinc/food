<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateJobSubcategoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('job_subcategories', function (Blueprint $table) {
            $table->smallIncrements('id');

            $table->unsignedSmallInteger('categody_id')->nullable();;
            $table->foreign('categody_id')->references('id')->on('job_categories')->onDelete('set null');

            $table->string('sub_category_name')->default('');


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('job_subcategories');
    }
}
