<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCompaniesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('companies', function (Blueprint $table) {
            $table->smallIncrements('id');
            
            $table->unsignedSmallInteger('industry_id')->nullable();;
            $table->foreign('industry_id')->references('id')->on('industries')->onDelete('set null');


            $table->unsignedBigInteger('state_id')->nullable();;
            $table->foreign('state_id')->references('id')->on('states')->onDelete('set null');

            $table->unsignedBigInteger('district_id')->nullable();;
            $table->foreign('district_id')->references('id')->on('districts')->onDelete('set null');


            $table->string('company_name')->default('')->nullable();
            $table->string('address')->default('')->nullable();
            $table->string('longitude')->default('')->nullable();
            $table->string('latitude')->default('')->nullable();
            $table->string('nagar_palika',50)->default('')->nullable();
            $table->string('block',50)->default('')->nullable();
            $table->string('village',50)->default('')->nullable();
            $table->string('house_number',20)->default('')->nullable();
            $table->string('polic_station',50)->default('')->nullable();
            $table->string('pin_code',10)->default('')->nullable();
            $table->string('logo')->default('')->nullable();
            $table->string('url')->default('')->nullable();
            $table->text('description')->nullable();
            $table->boolean('is_consultant')->default(false);
            $table->boolean('status')->default(0);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('companies');
    }
}
